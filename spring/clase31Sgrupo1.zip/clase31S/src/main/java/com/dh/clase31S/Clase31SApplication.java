package com.dh.clase31S;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase31SApplication {

	public static void main(String[] args) {
		SpringApplication.run(Clase31SApplication.class, args);
	}

}
