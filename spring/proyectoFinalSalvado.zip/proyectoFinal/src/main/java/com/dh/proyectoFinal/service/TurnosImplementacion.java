package com.dh.proyectoFinal.service;

import com.dh.proyectoFinal.repository.IDao;
import com.dh.proyectoFinal.entity.Turno;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class TurnosImplementacion implements ITurnosService{

    private IDao<Turno> turnoIDao;

    @Autowired
    public TurnosImplementacion(IDao<Turno> turnoIDao) {
        this.turnoIDao = turnoIDao;
    }


    @Override
    public List<Turno> listadoTurnos() {
        return turnoIDao.listarElementos();
    }

    @Override
    public Turno registrarTurno(Turno t) {
        return turnoIDao.guardar(t);
    }

    @Override
    public Turno actualizarTurno(Turno t) {
        return turnoIDao.actualizar(t);

    }

    @Override
    public void eliminarTurno(int id) {
        turnoIDao.eliminar(id);
    }


    @Override
    public Turno buscarTurno(int id) {
        return turnoIDao.buscarXId(id);
    }
}
