package com.dh.clase32;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase32ApplicationTests {

	@Test
	void contextLoads() {
	}

}
